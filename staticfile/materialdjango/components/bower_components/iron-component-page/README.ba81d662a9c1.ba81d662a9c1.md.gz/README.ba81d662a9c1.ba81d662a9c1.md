
<!---

This README is automatically generated from the comments in these files:
iron-component-page.html

Edit those files, and our readme bot will duplicate them over here!
Edit this file, and the bot will squash your changes :)

-->

[![Build Status](https://travis-ci.org/PolymerElements/iron-component-page.svg?branch=master)](https://travis-ci.org/PolymerElements/iron-component-page)

_[Demo and API Docs](https://elements.polymer-project.org/elements/iron-component-page)_


##&lt;iron-component-page&gt;


Loads Polymer element and behavior documentation using
[Hydrolysis](https://github.com/PolymerLabs/hydrolysis) and renders a complete
documentation page including demos (if available).

